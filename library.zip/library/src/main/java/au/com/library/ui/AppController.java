package au.com.library.ui;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import au.com.library.dao.LibraryDao;
import au.com.library.entity.Books;
import au.com.library.entity.Person;

/**
 * The Class HelloController.
 */
@Controller
public class AppController {
	
	/** The library dao. */
	@Autowired
    private LibraryDao libraryDao;

	/**
	 * Prints the welcome.
	 *
	 * @param model the model
	 * @return the string
	 */
	@RequestMapping(value = "/admin/launch", method = RequestMethod.GET)
	public String printWelcome(@ModelAttribute("model") ModelMap model) {
		List<Person> persons=libraryDao.getAllPerson();
		model.addAttribute("personsList", persons);
		List<Books> books=libraryDao.getAllBooks();
		model.addAttribute("booksList", books);
		return "admin";

	}
	
	/**
	 * Processes the ajax request for getting the Books held by a Person
	 *
	 * @param id the id
	 * @return the string
	 */
	@RequestMapping(value = "/admin/search", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody String Submit(@RequestParam("personId") String id) {
		Collection<Books> lentBooks=libraryDao.getBooksById(Integer.valueOf(id));
		ObjectMapper mapper=new ObjectMapper();
	    try {
			return mapper.writeValueAsString(lentBooks);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
	    return "";
	}


	


}
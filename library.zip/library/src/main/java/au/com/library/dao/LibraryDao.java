package au.com.library.dao;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Component;

import au.com.library.entity.Books;
import au.com.library.entity.Person;

/**
 * The Class LibraryDao.
 */
@Component("LibraryDao")
public class LibraryDao {

	/** The em. */
	@PersistenceContext
	private EntityManager em;

	/**
	 * Gets the customer by name.
	 *
	 * @param personId the person id
	 * @return the customer by name
	 */
	public Person getCustomerByName(int personId) {
		Query query = getEm().createQuery("SELECT p FROM Person p WHERE p.id = ?1");
		query.setParameter(1, personId);
		List<Person> results = query.getResultList();
		if (results.size() > 0) {
			return results.get(0);
		}
		return null;
	}
	
	/**
	 * Gets the all person.
	 *
	 * @return the all person
	 */
	public List<Person> getAllPerson() {
		Query query = getEm().createQuery("SELECT p FROM Person p");
		List<Person> results = query.getResultList();
		return results;
	}
	
	/**
	 * Gets the all books.
	 *
	 * @return the all books
	 */
	public List<Books> getAllBooks() {
		Query query = getEm().createQuery("SELECT b FROM Books b");
		List<Books> results = query.getResultList();
		return results;
	}
	
	/**
	 * Gets the books by id.
	 *
	 * @param personId the person id
	 * @return the books by id
	 */
	public Collection<Books> getBooksById(int personId) {
		Query query = getEm().createQuery("SELECT p FROM Person p where p.id=:personId");
		query.setParameter("personId", personId);
		Person p= (Person) query.getSingleResult();
		Collection<Books> returnList = p.getBooks()!=null?p.getBooks():new HashSet<Books>();
		return returnList;
	}

	/**
	 * Gets the em.
	 *
	 * @return the em
	 */
	protected EntityManager getEm() {
		return em;
	}
}
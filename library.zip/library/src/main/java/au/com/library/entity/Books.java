package au.com.library.entity;

import java.util.Collection;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

/**
 * The Class Books.
 */
@Entity(name = "Books")
@Table(name = "BOOKS")
public class Books {
	
	/** The id. */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BOOK_ID")
	private Integer id;
	
	/** The name. */
	@Column(name = "TITLE")
	private String name;
	
	/** The author. */
	@Column(name = "AUTHOR")
	private String author;
	
	/** The isbn. */
	@Column(name = "ISBN")
	private String isbn;
	
	/** The persons. */
	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.REMOVE })
	@OrderBy
	@JoinTable(name = "LENT", joinColumns = {
			@JoinColumn(name = "BOOK_ID", referencedColumnName = "BOOK_ID") }, inverseJoinColumns = {
					@JoinColumn(name = "PERSON_ID", referencedColumnName = "PERSON_ID") })
	private Collection<Person> persons;

	/**
	 * Instantiates a new books.
	 */
	public Books() {
		super();
	}

	/**
	 * Gets the id.
	 *
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * Sets the id.
	 *
	 * @param id the new id
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the author.
	 *
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Sets the author.
	 *
	 * @param author the new author
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * Gets the isbn.
	 *
	 * @return the isbn
	 */
	public String getIsbn() {
		return isbn;
	}

	/**
	 * Sets the isbn.
	 *
	 * @param isbn the new isbn
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	/**
	 * Gets the persons.
	 *
	 * @return the persons
	 */
	public Collection<Person> getPersons() {
		return persons;
	}

	/**
	 * Sets the persons.
	 *
	 * @param persons the new persons
	 */
	public void setPersons(Collection<Person> persons) {
		this.persons = persons;
	}
}

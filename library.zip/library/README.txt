Command to start the application.
mvn jetty-run

The interface can be accessed on http://localhost:8080/library/admin/launch 
The sql files that seed the data are in folder src\main\resources\db\sql\**
The app uses
    H2 In memory database,Jetty, OpenJPA, FreeMarker template, Spring MVC 4, Jackson,
Screen shots of the application are in file screen-shots.docx